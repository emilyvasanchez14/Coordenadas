
import java.util.Scanner;


/**
 *
 * @author Emily Valentina Sánchez Pedraza
 * 6000992
 */
public class Coordenadas
{

    public static void main(String[] args)
    {
       Scanner scanner = new Scanner(System.in);
       System.out.print("Ingrese el radio (r): ");
       double radio = scanner.nextDouble();
       
       System.out.print("Ingrese el angulo en grados (°): ");
       double angulo = scanner.nextDouble();
       
       double angulorad = Math.toRadians(angulo); // pasar de grados a radianes
       
       //convertir las coordenadas polares a rectangulares
       double x = radio * Math.cos(angulorad);
       double y = radio * Math.sin(angulorad);
       
       System.out.print("x: " + x);
       System.out.print("\n");
       System.out.print("y: " + y);
       System.out.print("\n");
               
               
    }
    
}
